package hlt;

import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

import core.Fleet;
import core.VectorBasic;

import static hlt.Constants.DOCK_RADIUS;
import static hlt.Constants.WEAPON_RADIUS;

public class Navigation
{
    public static ThrustMove navigateShipToMove( final GameMap gameMap, final Ship ship, final Entity moveTarget, final int maxThrust)
    {
        final int maxCorrections = 90;
        final boolean avoidObstacles = true;
        final double angularStepRad = Math.PI/45.0;
        final double minimumDistance = moveTarget.getRadius() + ship.getRadius() + 1.0;

        return navigateShipTowardsTarget(gameMap, ship, moveTarget, maxThrust, avoidObstacles, maxCorrections, minimumDistance, angularStepRad);
    }
    
    public static ThrustMove navigateShipToMoveTangent( final GameMap gameMap, final Ship ship, final Entity moveTarget, final int maxThrust)
    {
        final int maxCorrections = 90;
        final boolean avoidObstacles = true;
        final double angularStepRad = Math.PI/45.0;
        final double minimumDistance = moveTarget.getRadius() + ship.getRadius() + 1.0;

        return navigateTowards3(gameMap, ship, moveTarget, maxThrust, avoidObstacles, maxCorrections, minimumDistance,true);
    }

    public static ThrustMove navigateShipToDock( final GameMap gameMap, final Ship ship, final Entity dockTarget, final int maxThrust)
    {
        final int maxCorrections = 90;
        final boolean avoidObstacles = true;
        final double angularStepRad = Math.PI/45.0;
        final double minimumDistance = dockTarget.getRadius() + ship.getRadius() + 1.0;

        return navigateShipTowardsTarget(gameMap, ship, dockTarget, maxThrust, avoidObstacles, maxCorrections, minimumDistance, angularStepRad);
    }
    
    public static ThrustMove navigateShipToDockTangent( final GameMap gameMap, final Ship ship, final Entity dockTarget, final int maxThrust)
    {
        final int maxCorrections = 90;
        final boolean avoidObstacles = true;
        final double angularStepRad = Math.PI/45.0;
        final double minimumDistance = dockTarget.getRadius() + ship.getRadius() + 1.0;

        return navigateTowards3(gameMap, ship, dockTarget, maxThrust, avoidObstacles, maxCorrections, minimumDistance,true);
    }
    
    public static ThrustMove navigateShipToCrashInto( final GameMap gameMap, final Ship ship, final Entity crashTarget, final int maxThrust)
    {
        final int maxCorrections = 90;
        final boolean avoidObstacles = true;
        final double angularStepRad = Math.PI/45.0;
        final double minimumDistance = 0;
 
        return navigateShipTowardsTarget(gameMap, ship, crashTarget, maxThrust, avoidObstacles, maxCorrections, minimumDistance, angularStepRad);
    }
 
    public static ThrustMove navigateShipToAttack( final GameMap gameMap, final Ship ship, final Entity attackTarget, final int maxThrust)
    {
        final int maxCorrections = 90;
        final boolean avoidObstacles = true;
        final double angularStepRad = Math.PI/45.0;
        final double minimumDistance = attackTarget.getRadius() + ship.getRadius() + 1.0;
 
        return navigateShipTowardsTarget(gameMap, ship, attackTarget, maxThrust, avoidObstacles, maxCorrections, minimumDistance, angularStepRad);
    }
    
    public static ArrayList<ThrustMove> navigateFleetToAttack( final GameMap gameMap, final Fleet fleet, final Entity attackTarget, final int maxThrust)
    {
        final int maxCorrections = 90;
        final boolean avoidObstacles = true;
        final double angularStepRad = Math.PI/45.0;
        final double minimumDistance = attackTarget.getRadius() + Constants.SHIP_RADIUS + 1.0;
 
        return navigateFleetSizeTwoTowards(gameMap, fleet, attackTarget, maxThrust, avoidObstacles, maxCorrections, minimumDistance);
    }

    public static ThrustMove navigateShipTowardsTarget(
            final GameMap gameMap,
            final Ship ship,
            final Position targetPos,
            final int maxThrust,
            final boolean avoidObstacles,
            final int maxCorrections,
            final double minimumDistance,
            final double angularStepRad
    )
    {
        if (maxCorrections <= 0)
            return new ThrustMove(ship, 0, 0);

        final double distance = ship.getDistanceTo(targetPos);
        final double angleRad = ship.orientTowardsInRad(targetPos);

        if (avoidObstacles && !gameMap.objectsBetween(ship, targetPos).isEmpty())
        {
            final double newTargetDx = Math.cos(angleRad + angularStepRad) * distance;
            final double newTargetDy = Math.sin(angleRad + angularStepRad) * distance;
            final Position newTarget = new Position(ship.getXPos() + newTargetDx, ship.getYPos() + newTargetDy);

            return navigateShipTowardsTarget(gameMap, ship, newTarget, maxThrust, true, (maxCorrections-1), minimumDistance, angularStepRad);
        }

        final int thrust;
        if (distance - minimumDistance < maxThrust)
        {
            // Do not round up, since overshooting might cause collision.
            thrust = (int) (Math.max(distance - minimumDistance, 0.0));
        }
        else
        {
            thrust = maxThrust;
        }

        final int angleDeg = Util.angleRadToDegClipped(angleRad);

        return new ThrustMove(ship, angleDeg, thrust);
    }

    public static ThrustMove navigateTowards2(final GameMap gameMap,Ship ship, final Position targetPos, final int maxThrust, final boolean avoidObstacles)
	{
		double distance = ship.getDistanceTo(targetPos);
		double angleRad = ship.orientTowardsInRad(targetPos);

		final ArrayList<Entity> objectsBetween = gameMap.objectsBetween(ship, targetPos);

		if (avoidObstacles && !objectsBetween.isEmpty())
		{
			Map<Double,Entity> nearbyEntitiesByAngle = new TreeMap<>();
			Double maxAngle = Double.NEGATIVE_INFINITY;
			Entity maxEntity = ship;
			Double maxDistance = 0.0;
			for(final Entity entity : objectsBetween)
			{
				Double angleToEntity = ship.orientTowardsInRad(entity);
				nearbyEntitiesByAngle.put(angleToEntity, entity);
				if(angleToEntity > maxAngle)
				{
					maxAngle = angleToEntity;
					maxEntity = entity;
					maxDistance = ship.getDistanceTo(entity);
				}
			}
			DebugLog.addLog(ship.toString());
			DebugLog.addLog(maxEntity.toString());
			DebugLog.addLog(maxAngle.toString());

			Double radialSize = maxEntity.getRadius() * 0.5 / maxDistance * Math.PI * 2;

			angleRad = maxAngle + radialSize;
			distance = maxDistance;
		}

		final int thrust;
		if (distance < maxThrust)
		{
			// Do not round up, since overshooting might cause collision.
			thrust = (int) distance;
		}
		else
			thrust = maxThrust;

		final int angleDeg = Util.angleRadToDegClipped(angleRad);
		return new ThrustMove(ship, angleDeg, thrust);
	}

    public static ThrustMove navigateTowards3(
		final GameMap gameMap,
		Ship ship,
		final Position targetPos,
		final int maxThrust,
		final boolean avoidObstacles,
		final int maxCorrections,
		final double minimumDistance,
		boolean isFinalDestination
	)
	{
    	// Still iterative, but not in fixed step sizes
    	// computes the step size based on the objects
    	
    	final double distance = ship.getDistanceTo(targetPos);

    	if (maxCorrections <= 0 || distance < 1.2)
    	{
    		//fall back to old navigation
    		final int maxCorrectionsFallback = 90;
            final boolean avoidObstaclesFallback = true;
            final double angularStepRad = Math.PI/45.0;
            
            return navigateShipTowardsTarget(gameMap, ship, targetPos, maxThrust, avoidObstacles, maxCorrectionsFallback, minimumDistance, angularStepRad);
        }

        final double angleRad = ship.orientTowardsInRad(targetPos);
        ArrayList<Entity> entityList = gameMap.objectsBetween(ship, targetPos);
        
        Position newTarget;
        
        if (avoidObstacles && !entityList.isEmpty())
        {
			Entity e = getClosestEntity(entityList,ship);

        	ArrayList<Position> tangents = findTangentPointsToTarget(ship,e);
        	
        	Position tangent1 = tangents.get(0);
        	Position tangent2 = tangents.get(1);

			newTarget = (tangent1.getDistanceTo(targetPos) < tangent2.getDistanceTo(targetPos))? tangent1 : tangent2;
        	
        	return navigateTowards3(gameMap, ship, newTarget,  maxThrust,
             avoidObstacles,maxCorrections-1, Constants.SHIP_RADIUS + 0.1,false);
        	
        }

        int thrust;
        if (distance - minimumDistance < maxThrust)
        {
            thrust = (int) (Math.max(distance - minimumDistance, 0.0));
            //dealing with scenarios where the thrust is rounded down to 0
            
            if(thrust == 0)
            	if(!isFinalDestination)
            		thrust = 1;
        }
        else
            thrust = maxThrust;

        final int angleDeg = Util.angleRadToDegClipped(angleRad);
        return new ThrustMove(ship, angleDeg, thrust);
	}

	public static ArrayList<Position> findTangentPointsToTarget(final Position point, final Entity target)
	{
		double circleRadius = target.getRadius()+ 1.5;
		double distanceToCenter = target.getDistanceTo(point);

		double x = point.getXPos();
		double y = point.getYPos();

		double tangentLength = Math.sqrt(distanceToCenter * distanceToCenter - circleRadius * circleRadius);
		double angleRad = point.orientTowardsInRad(target);
		double radialWidth = Math.atan2(circleRadius, tangentLength);

		double x1 = tangentLength* Math.cos(angleRad + radialWidth);
		double x2 = tangentLength* Math.cos(angleRad - radialWidth);

		double y1 = tangentLength* Math.sin(angleRad + radialWidth);
		double y2 = tangentLength* Math.sin(angleRad - radialWidth);

		Position tgt1 = new Position(x + x1,y+y1);
		Position tgt2 = new Position(x + x2,y+y2);

		ArrayList<Position> tangents = new ArrayList<>();
		tangents.add(tgt1);
		tangents.add(tgt2);
		return tangents;
	}

	public static Entity getClosestEntity(final ArrayList<Entity> entityList, final Position p)
	{
		double minDistance = Double.MAX_VALUE;
		double distance;
		Entity closestEntity = null;
		for(final Entity entity: entityList)
		{
			distance = p.getDistanceTo(entity);
			if(distance < minDistance)
			{
				closestEntity = entity;
				minDistance = distance;
			}
		}

		return closestEntity;
	}

    public static ArrayList<ThrustMove> navigateFleetSizeTwoTowards(
    		final GameMap gameMap,
    		Fleet fleet, 
    		final Position targetPos,
    		final int maxThrust,
    		final boolean avoidObstacles,
    		final int maxCorrections,
    		final double minimumDistance
	)
	{
    	int fleetSize = fleet.getShips().size();
    	ArrayList<ThrustMove> moveList = new ArrayList<ThrustMove>();
    	ArrayList<Ship> shipList = fleet.getShips();
    	double maxDistance = 0;
    	double spacing = 1.0;
    	ArrayList<VectorBasic> relativePositions = new ArrayList<VectorBasic>();
    	ArrayList<Position> newTargets = new ArrayList<Position>();
    	
    	if(fleetSize != 2) {
    		for(Ship s:shipList) {
    			moveList.add(navigateTowards3(gameMap,
    					s,targetPos,maxThrust,
    					avoidObstacles,maxCorrections,minimumDistance,true));
    		}
    		return moveList;
    	}else {
    		Ship anchorShip = shipList.get(0);
        	ThrustMove anchorMove = navigateTowards3(gameMap,
        			anchorShip,targetPos,maxThrust,
        			avoidObstacles,maxCorrections,minimumDistance,true);
        	
        	moveList.add(anchorMove);
        	Position anchorPosition = new Position(anchorShip.getXPos() + anchorMove.dX(),
        			anchorShip.getYPos() + anchorMove.dY() );
        	
        	Position newTarget = anchorPosition;
    		
        	Ship followShip = shipList.get(1);
        	
        	ThrustMove newMove = navigateTowards3(gameMap,
        			followShip,newTarget,maxThrust,
        			avoidObstacles,maxCorrections,minimumDistance,true);
        	
        	moveList.add(newMove);
        	
        	moveList = combineMoves(moveList);
        	
        	return moveList;
    	}
	}
    
    public static ArrayList<ThrustMove> combineMoves(ArrayList<ThrustMove> inputMoves){
    	ThrustMove m1 = inputMoves.get(0);
    	ThrustMove m2 = inputMoves.get(1);
    	
    	VectorBasic v1 = new VectorBasic(m1.getShip().getXPos(), m1.getShip().getYPos());
        VectorBasic v2 = new VectorBasic(m2.getShip().getXPos(), m2.getShip().getYPos());
        
        
        double scalingFactor = 1;
        for (double i = 0.0; i <= 1; i += 0.1)
        {
            VectorBasic r1 = new VectorBasic(m1.dX() * i, m1.dY() * i);
            VectorBasic r2 = new VectorBasic(m2.dX() * i, m2.dY() * i);

            VectorBasic p1 = v1.add(r1);
            VectorBasic p2 = v2.add(r2);

            if (p1.subtract(p2).length() < Constants.SHIP_RADIUS * 2 + 0.1)
            {
            	scalingFactor = i - 0.1;
            	m1 = rescaleMove(m1,scalingFactor);
            	m2 = rescaleMove(m2,scalingFactor);
            	inputMoves.set(0, m1);
            	inputMoves.set(1, m2);
            	
                break;
            }
        }

        return inputMoves;
    }

    public static ThrustMove rescaleMove(ThrustMove m,double scalingFactor)
	{
    	int thrust = m.getThrust();
    	int newThrust = (int)(thrust * scalingFactor);
    	m.setThrust(newThrust);
    	return m;
    }
}