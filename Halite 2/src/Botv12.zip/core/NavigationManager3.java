package core;

import core.CombatManager.CombatManager;
import hlt.*;

import java.util.ArrayList;

import static core.Objective.OrderType.*;

public class NavigationManager3
{
    public void moveFleetsToObjectiveV2(final GameState gameState, final ArrayList<Move> moveList)
    {
        for (final Fleet fleet: gameState.getFleetManager().getFleets())
            moveFleetToObjectiveV2(gameState, moveList, fleet, gameState.getBehaviourManager());
    }

    public void moveFleetToObjectiveV2(final GameState gameState, ArrayList<Move> moveList, final Fleet fleet, final BehaviourManager behaviourManager)
    {
        
        Objective objective = fleet.getObjectives().get(0);
        Objective.OrderType orderType = objective.getOrderType();
        Entity target = objective.getTargetEntity();


        switch (orderType)
        {
            case DEFEND:
            	for(final Ship ship: fleet.getShips())
                {
                    Move newMove;
            		newMove = moveFleetToObjectiveDefend(gameState, ship, target);
                    if (newMove != null)
                    {
                        moveList.add(newMove);
                        gameState.moveShip(ship, newMove);
                    }

                }
                
                
                break;
            case COLONIZE: case REINFORCECOLONY:
            	for(final Ship ship: fleet.getShips())
                {
            		Move newMove;
            		newMove = moveFleetToObjectiveColonize(gameState, ship, target);
                    if (newMove != null)
                    {
                        moveList.add(newMove);
                        gameState.moveShip(ship, newMove);
                    }

                }
                break;
            case RUSH: case ANTIRUSH: case ATTACK:
            	
            	ArrayList<ThrustMove> moves = moveFleetToObjectiveAttackV2(gameState, fleet, target);
            	for(final ThrustMove newMove: moves)
                {
            		if (newMove != null)
                    {
                        moveList.add(newMove);
                        gameState.moveShip(newMove.getShip(), newMove);
                    }

                }
                
                break;
            case CRASHINTO:
            	for(final Ship ship: fleet.getShips())
                {
            		Move newMove;
            		newMove = moveFleetToObjectiveCrashInto(gameState, ship, target);
                    if (newMove != null)
                    {
                        moveList.add(newMove);
                        gameState.moveShip(ship, newMove);
                    }

                }
                
                break;
            default:
            	break;
        }
    }

    private Move moveFleetToObjectiveDefend(final GameState gameState, final Ship ship, final Entity target)
    {
        return(Navigation.navigateShipToMoveTangent(gameState.getGameMap(), ship, target, Constants.MAX_SPEED));
    }

    private Move moveFleetToObjectiveColonize(final GameState gameState, final Ship ship, final Entity target)
    {
        Planet planet = (target instanceof Planet ? (Planet)target : null);

        if (ship.canDock(planet))
            return new DockMove(ship, planet);
        else
            return Navigation.navigateShipToDockTangent(gameState.getGameMap(), ship, target, Constants.MAX_SPEED);
    }

    private Move moveFleetToObjectiveAttack(final GameState gameState, final Ship ship, final Fleet fleet, final Entity target)
    {
        Move newMove = Navigation.navigateShipToAttack(gameState.getGameMap(), ship, target, Constants.MAX_SPEED);
        double newMoveScore = CombatManager.scoreMove(ship, (Ship) target, (ThrustMove) newMove, gameState);

        Move retreatMove = Navigation.navigateShipToMoveTangent(gameState.getGameMap(), ship, retreatTarget(gameState, ship, fleet), Constants.MAX_SPEED);
        double retreatMoveScore = CombatManager.scoreMove(ship, (Ship) target, (ThrustMove) retreatMove, gameState);

//        Move crashMove = Navigation.navigateShipToCrashInto(gameState.getGameMap(), ship, target, Constants.MAX_SPEED);
//        double crashMoveScore = CombatManager.scoreCrashMove(ship, (Ship) target, (ThrustMove) crashMove, gameState);

        if (newMoveScore < retreatMoveScore)
            return retreatMove;
        else
            return newMove;
    }
    
    private ArrayList<ThrustMove> moveFleetToObjectiveAttackV2(final GameState gameState,  final Fleet fleet, final Entity target)
    {
 
    	 ArrayList<ThrustMove> moves =  Navigation.navigateFleetToAttack(
        		gameState.getGameMap(),fleet,target,
        		Constants.MAX_SPEED);
    	 return moves;
 
    }
    

    private Move moveFleetToObjectiveCrashInto(final GameState gameState, final Ship ship, final Entity target)
    {
        return(Navigation.navigateShipToCrashInto(gameState.getGameMap(), ship, target, Constants.MAX_SPEED));
    }

    private Entity retreatTarget(final GameState gameState, final Ship targetShip, final Fleet fleet)
    {
        if (fleet.getShips().size() > 1)
            return fleet.FleetCentroid();
        else
            return gameState.getDistanceManager().getClosestShip(targetShip);
    }
}
