package core.CombatManager;

public enum EventType
{
    ATTACK,
    ATTACKDOCKED,
    DEFEND,
    GROUP,
    RETREAT,
    STILL
}
