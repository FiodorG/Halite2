package core;

import core.CombatManager.CombatManager;
import hlt.*;

import java.util.ArrayList;

public class NavigationManager
{
    private ArrayList<Move> moves;

    public ArrayList<Move> getMoves() { return moves; }

    public NavigationManager()
    {
        this.moves = new ArrayList<>();
    }

    public ArrayList<Move> generateMoves(final GameState gameState)
    {
        clearMoves();

        moveFleetsToObjective(gameState, gameState.getBehaviourManager());
        moveShipsToObjective(gameState, gameState.getFleetManager().getAvailableShipsNotInFleets(), gameState.getBehaviourManager());

        resolveMoves();
        logMoves();

        return this.moves;
    }

    private void moveFleetsToObjective(final GameState gameState, final BehaviourManager behaviourManager)
    {
        for (final Fleet fleet: gameState.getFleetManager().getFleets())
        {
            Objective objective = fleet.getObjectives().get(0);
            Objective.OrderType orderType = objective.getOrderType();
            Entity target = objective.getTargetEntity();

            ArrayList<Move> newMoves;

            switch (orderType)
            {
                case GROUP:
                    newMoves = moveFleetToObjectiveGroup(gameState, fleet);
                    break;
                case RUSH: case ANTIRUSH: case ATTACK:
                    newMoves = moveFleetToObjectiveAttack(gameState, fleet, target);
                    break;
                default:
                    throw new IllegalStateException("Unknown orderType for Fleet issued.");
            }

            if (!newMoves.isEmpty())
            {
                this.moves.addAll(newMoves);
                gameState.moveShips(fleet.getShips(), newMoves);
                gameState.moveFleet(fleet, newMoves);
            }
        }
    }

    private ArrayList<Move> moveFleetToObjectiveAttack(final GameState gameState, final Fleet fleet, final Entity target)
    {
        ArrayList<Move> newMoves = Navigation.navigateFleetToAttack(gameState, fleet, target);
        double newMovesScore = CombatManager.scoreFleetMove(fleet, (Ship) target, newMoves, gameState);

        ArrayList<Move> retreatMoves = Navigation.navigateFleetToAttack(gameState, fleet, gameState.getDistanceManager().getClosestAllyShipFromFleet(fleet));
        double retreatMovesScore = CombatManager.scoreFleetMove(fleet, (Ship) target, retreatMoves, gameState);

        if (newMovesScore < retreatMovesScore)
        {
            fleet.setUnderAttackMode();
            return retreatMoves;
        }
        else
            return newMoves;
    }

    private ArrayList<Move> moveFleetToObjectiveGroup(final GameState gameState, final Fleet fleet)
    {
        return Navigation.navigateFleetToGroup(gameState, fleet);
    }

    private void moveShipsToObjective(final GameState gameState, final ArrayList<Ship> ships, final BehaviourManager behaviourManager)
    {
        for(final Ship ship: ships)
        {
            Objective objective = ship.getObjective();
            Objective.OrderType orderType = objective.getOrderType();
            Entity target = objective.getTargetEntity();

            Move newMove;

            switch (orderType)
            {
                case DEFEND:
                    newMove = moveShipToObjectiveDefend(gameState, ship, target);
                    break;
                case COLONIZE: case REINFORCECOLONY:
                    newMove = moveShipToObjectiveColonize(gameState, ship, target);
                    break;
                case RUSH: case ANTIRUSH: case ATTACK:
                    newMove = moveShipToObjectiveAttack(gameState, ship, target);
                    break;
                case CRASHINTO:
                    newMove = moveShipToObjectiveCrashInto(gameState, ship, target);
                    break;
                case GROUP:
                    newMove = moveShipToObjectiveGroup(gameState, ship, target);
                    break;
                default:
                    throw new IllegalStateException("Unknown orderType for ship issued.");
            }

            if (newMove != null)
            {
                this.moves.add(newMove);
                gameState.moveShip(ship, newMove);
            }
        }
    }

    private Move moveShipToObjectiveDefend(final GameState gameState, final Ship ship, final Entity target)
    {
        return(Navigation.navigateShipToMove(gameState, ship, target));
    }

    private Move moveShipToObjectiveColonize(final GameState gameState, final Ship ship, final Entity target)
    {
        Planet planet = (target instanceof Planet ? (Planet)target : null);

        if (ship.canDock(planet))
            return new DockMove(ship, planet);
        else
            return Navigation.navigateShipToDock(gameState, ship, target);
    }

    private Move moveShipToObjectiveAttack(final GameState gameState, final Ship ship, final Entity target)
    {
        Move newMove = Navigation.navigateShipToAttack(gameState, ship, target);
        double newMoveScore = CombatManager.scoreShipMove(ship, (Ship) target, (ThrustMove) newMove, gameState);

        Move retreatMove = Navigation.navigateShipToMove(gameState, ship, gameState.getDistanceManager().getClosestAllyShip(ship));
        double retreatMoveScore = CombatManager.scoreShipMove(ship, (Ship) target, (ThrustMove) retreatMove, gameState);

//        Move crashMove = Navigation.navigateShipToCrashInto(gameState.getGameMap(), ship, target, Constants.MAX_SPEED);
//        double crashMoveScore = CombatManager.scoreCrashMove(ship, (Ship) target, (ThrustMove) crashMove, gameState);

        if (newMoveScore < retreatMoveScore)
            return retreatMove;
        else
            return newMove;
    }

    private Move moveShipToObjectiveCrashInto(final GameState gameState, final Ship ship, final Entity target)
    {
        return(Navigation.navigateShipToCrashInto(gameState, ship, target));
    }

    private Move moveShipToObjectiveGroup(final GameState gameState, final Ship ship, final Entity entity)
    {
        if (!(entity instanceof Fleet))
            throw new IllegalStateException("Can't group to non fleets.");

        // Get fleet after move was updated.
        Fleet oldFleet = (Fleet) entity;
        int indexOfFleet = gameState.getMyFleetsNextTurn().indexOf(oldFleet);
        Fleet fleet = gameState.getMyFleetsNextTurn().get(indexOfFleet);

        boolean isClose = (ship.getDistanceTo(fleet.getCentroid()) < 7.1);

        if (isClose)
        {
            final ArrayList<Entity> entities = gameState.objectsBetween(ship, fleet, ship.getRadius() + 0.1);
            entities.removeAll(fleet.getShips());
            if (entities.isEmpty())
                oldFleet.addShip(ship);
        }

        return Navigation.navigateShipToMove(gameState, ship, fleet.getCentroid());
    }

    private void resolveMoves()
    {
        Move move1;
        Move move2;
        for(int i = 0; i < this.moves.size(); i++)
        {
            move1 = this.moves.get(i);
            for(int j = 0; j < i; j++)
            {
                move2 = this.moves.get(j);

                Boolean eitherDocking   = move1.getType() == Move.MoveType.Dock || move2.getType() == Move.MoveType.Dock;
                Boolean eitherUnDocking = move1.getType() == Move.MoveType.Undock || move2.getType() == Move.MoveType.Undock;
                Boolean eitherStopped   = move1.getType() == Move.MoveType.Noop || move2.getType() == Move.MoveType.Noop;

                if(!(eitherDocking || eitherUnDocking || eitherStopped))
                {
                    ThrustMove thrustMove1 = (ThrustMove) move1;
                    ThrustMove thrustMove2 = (ThrustMove) move2;

                    if(Collision.willCollideIterative(thrustMove1, thrustMove2))
                    {
                        if (thrustMove1.getPriorityMove() > thrustMove2.getPriorityMove())
                            this.moves.set(j, new ThrustMove(thrustMove2.getShip(), 0, 0, thrustMove2.getPriorityMove()));
                        else
                            this.moves.set(i, new ThrustMove(thrustMove1.getShip(), 0, 0, thrustMove1.getPriorityMove()));
                    }
                }
            }
        }
    }

    private void clearMoves() { this.moves.clear(); }
    private void logMoves()
    {
        for(final Move move: this.moves)
            DebugLog.addLog(move.toString());
    }
}
