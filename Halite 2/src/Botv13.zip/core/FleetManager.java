package core;

import hlt.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import static core.Config.numberOfClosestObjectives;

public class FleetManager
{
    private ArrayList<Ship> availableShips;
    private ArrayList<Ship> availableShipsNotInFleets;

    private ArrayList<Fleet> fleets;
    private HashMap<Integer, Fleet> shipToFleets;
    private int FleetId;

    private ArrayList<Objective> unfilledObjectives;
    private ArrayList<Objective> filledObjectives;

    public FleetManager()
    {
        this.availableShips = new ArrayList<>();
        this.availableShipsNotInFleets = new ArrayList<>();

        this.fleets = new ArrayList<>();
        this.shipToFleets = new HashMap<>();
        this.FleetId = 0;

        this.unfilledObjectives = new ArrayList<>();
        this.filledObjectives = new ArrayList<>();
    }

    public ArrayList<Fleet> getFleets() { return fleets; }
    public ArrayList<Ship> getAvailableShipsNotInFleets() { return availableShipsNotInFleets; }

    public void assignShips(final GameState gameState)
    {
        resetObjectives(gameState.getObjectiveManager().getObjectives());

        assignFleetsToObjectives(gameState);
        assignShipsToObjectives(gameState);
        assignShipsToFleets(gameState);

        logShips();
        logFleets();
    }

    public void assignFleetsToObjectives(final GameState gameState)
    {
        refreshFleets(gameState);

        for(final Fleet fleet: this.fleets)
        {
            HashMap<Objective, Double> objectivesAvailable = getAvailableObjectives(fleet.getCentroid(), gameState.getDistanceManager());
            Objective objective = selectObjective(objectivesAvailable, gameState.getBehaviourManager());
            updateObjective(objective, fleet);
        }
    }

    public void assignShipsToObjectives(final GameState gameState)
    {
        getAvailableShips(gameState);

        for(final Ship ship: this.availableShipsNotInFleets)
        {
            HashMap<Objective, Double> objectivesAvailable = getAvailableObjectives(ship, gameState.getDistanceManager());
            Objective objective = selectObjective(objectivesAvailable, gameState.getBehaviourManager());
            updateObjective(objective, ship);
        }
    }

    private void updateObjective(final Objective objective, final Entity entity)
    {
        if (entity instanceof Ship)
        {
            objective.decreaseRequiredShips(1);
            ((Ship)entity).setObjective(objective);
        }
        else if (entity instanceof Fleet)
        {
            objective.decreaseRequiredShips(((Fleet)entity).getShips().size());
            ((Fleet)entity).addObjective(objective);
        }

        if (objective.getRequiredShips() <= 0)
        {
            if (!filledObjectives.contains(objective))
                filledObjectives.add(objective);
            unfilledObjectives.remove(objective);
        }
    }

    private HashMap<Objective, Double> getAvailableObjectives(final Entity entity, final DistanceManager distanceManager)
    {
        ArrayList<Objective> filteredFilledObjectives = filterAttackObjectives(this.filledObjectives);
        ArrayList<Objective> filteredUnfilledObjectives = filterObjectives(this.unfilledObjectives, entity, distanceManager);

        if (filteredUnfilledObjectives.isEmpty())
            return DistanceManager.getClosestObjectiveFromEntity(filteredFilledObjectives, entity, numberOfClosestObjectives);
        else
            return DistanceManager.getClosestObjectiveFromEntity(filteredUnfilledObjectives, entity, numberOfClosestObjectives);
    }

    private Objective selectObjective(final HashMap<Objective, Double> closestObjectivesPriorities, final BehaviourManager behaviourManager)
    {
        Objective chosenObjective = null;
        double bestScore = -Double.MAX_VALUE;

        for (HashMap.Entry<Objective, Double> entry : closestObjectivesPriorities.entrySet())
        {
            Objective objective = entry.getKey();
            Double distance = entry.getValue();

            double score = behaviourManager.combinePriorityWithDistance(objective.getPriority(), distance);
            if (score > bestScore)
            {
                bestScore = score;
                chosenObjective = objective;
            }
        }

        return chosenObjective;
    }

    private ArrayList<Objective> filterObjectives(final ArrayList<Objective> objectives, final Entity entity, final DistanceManager distanceManager)
    {
        if (!(entity instanceof Ship))
            return filterAttackObjectives(objectives);
        else if (distanceManager.getClosestEnemyShipDistance((Ship) entity) <= 21)
            return filterAttackObjectives(objectives);
        else
            return objectives;
    }

    private ArrayList<Objective> filterAttackObjectives(final ArrayList<Objective> objectives)
    {
        // Select only attack objectives when all objectives have been filled (typically end of game)

        ArrayList<Objective> newObjectives = new ArrayList<>();
        for(final Objective objective: objectives)
        {
            if (objective.getOrderType() == Objective.OrderType.ATTACK)
                newObjectives.add(objective);
        }
        return newObjectives;
    }

    private void getAvailableShips(GameState gameState)
    {
        availableShips.clear();
        availableShipsNotInFleets.clear();

        for(final Ship ship: gameState.getMyShips())
            if (ship.isUndocked())
            {
                availableShips.add(ship);

                if (!shipToFleets.containsKey(ship.getId()))
                    availableShipsNotInFleets.add(ship);
            }
    }

    private void resetObjectives(final ArrayList<Objective> objectives)
    {
        this.unfilledObjectives.clear();
        this.unfilledObjectives = new ArrayList<>(objectives);
        this.filledObjectives.clear();
    }

    private void logShips()
    {
        for(final Ship ship: this.availableShips)
            DebugLog.addLog(ship.toString());
        DebugLog.addLog("");
    }

    private void assignShipsToFleets(final GameState gameState)
    {
        for(final Ship ship: availableShipsNotInFleets)
        {
            if (shipToFleets.containsKey(ship.getId()) || !ship.getObjective().isAttackObjective())
                continue;

            if (createNewFleet(ship, gameState))
                break;
            else
            {
                HashMap<Fleet, Double> fleetsAvailable = getAvailableFleets(ship, gameState.getDistanceManager());
                Fleet fleet = selectFleet(ship, fleetsAvailable, gameState.getBehaviourManager());

                if (fleet != null)
                {
                    ship.setObjective(new Objective(fleet, 100.0, 0, Objective.OrderType.GROUP, false, -1));
                    fleet.decreaseReinforcementNeed();
                }
            }
        }
    }

    private boolean createNewFleet(final Ship sourceShip, final GameState gameState)
    {
        for(final Ship ship: availableShipsNotInFleets)
        {
            if (shipToFleets.containsKey(ship.getId()) || ship.equals(sourceShip))
                continue;

            if (canGroup(sourceShip, ship, gameState))
            {
                sourceShip.setObjective(null);
                ship.setObjective(null);

                Fleet fleet = new Fleet(sourceShip, null, this.FleetId++);
                fleet.addShip(ship);
                fleet.addObjective(new Objective(fleet.getCentroid(),100.0,2, Objective.OrderType.GROUP,false, -1));
                this.fleets.add(fleet);
                this.shipToFleets.put(sourceShip.getId(), fleet);
                this.shipToFleets.put(ship.getId(), fleet);
                this.availableShipsNotInFleets.remove(sourceShip);
                this.availableShipsNotInFleets.remove(ship);
                return true;
            }
        }

        return false;
    }

    private boolean canGroup(final Ship ship1, final Ship ship2, final GameState gameState)
    {
        if (
            !shipToFleets.containsKey(ship1.getId())
            && !shipToFleets.containsKey(ship2.getId())
            && (ship1.getDistanceTo(ship2) < 14.0)
            && gameState.objectsBetween(ship1, ship2, ship1.getRadius() + 0.1).isEmpty()
            && ship1.getObjective().equals(ship2.getObjective())
        )
            return true;
        else
            return false;
    }

    private void refreshFleets(final GameState gameState)
    {
        // Remove dead ships, and refresh new ones,
        // remove all objectives.

        Iterator<Fleet> i = this.fleets.iterator();
        while (i.hasNext())
        {
            Fleet fleet = i.next();
            fleet.getObjectives().clear();
            boolean removeFleet = false;

            Iterator<Ship> j = fleet.getShips().iterator();
            while (j.hasNext())
            {
                Ship ship = j.next();
                int index = gameState.getMyShips().indexOf(ship);

                if (index == -1)
                {
                    // ship is dead
                    j.remove();
                    shipToFleets.remove(ship.getId());

                    if (fleet.getShips().size() <= 1)
                        removeFleet = true;
                }
                else
                {
                    // update ship
                    Ship updatedShip = gameState.getMyShips().get(index);
                    fleet.getShips().set(fleet.getShips().indexOf(ship), updatedShip);
                    this.shipToFleets.put(updatedShip.getId(), fleet);
                }
            }

            if (removeFleet)
            {
                // Put back ship into pool
                for(final Ship ship: fleet.getShips())
                {
                    this.availableShips.add(ship);
                    this.availableShipsNotInFleets.add(ship);
                    shipToFleets.remove(ship.getId());
                }
                i.remove();
            }
            else
                fleet.computeCentroid();
        }
    }

    private Fleet selectFleet(final Entity entity, final HashMap<Fleet, Double> fleetsAvailable, final BehaviourManager behaviourManager)
    {
        Fleet chosenFleet = null;
        double bestScore = -Double.MAX_VALUE;

        for (HashMap.Entry<Fleet, Double> entry : fleetsAvailable.entrySet())
        {
            Fleet fleet = entry.getKey();
            Double distance = entry.getValue();

            if (fleet.priorityReinforcementNeed() < ((Ship) entity).getObjective().getPriority())
                continue;

            double score = behaviourManager.combinePriorityWithDistance(fleet.priorityReinforcementNeed(), distance);
            if (score > bestScore)
            {
                bestScore = score;
                chosenFleet = fleet;
            }
        }

        return chosenFleet;
    }

    private HashMap<Fleet, Double> getAvailableFleets(final Entity entity, final DistanceManager distanceManager)
    {
        HashMap<Fleet, Double> fleetsAvailable = distanceManager.getClosestFleetsFromShip(this.fleets, entity, 5);
        HashMap<Fleet, Double> fleetsToChoose = new HashMap<>();

        for (HashMap.Entry<Fleet, Double> entry : fleetsAvailable.entrySet())
        {
            Fleet fleet = entry.getKey();
            if (fleet.getReinforcementNeed() > 0)
                fleetsToChoose.put(fleet, entry.getValue());
        }

        return fleetsToChoose;
    }

    private void logFleets()
    {
        for(final Fleet fleet: this.fleets)
            DebugLog.addLog(fleet.toString());
        DebugLog.addLog("");
    }
}